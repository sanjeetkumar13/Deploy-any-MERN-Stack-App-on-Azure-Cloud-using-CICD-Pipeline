module.exports = {
  //db: 'mongodb://localhost:27017/reactdb'
  db: 'mongodb://mernsms:qxaPSiychwHek4bCchBIUA7QN3apL5xLzpH6oY7jCA8pfogjUfVG49bQQ8IOwWOVRhvQFIVEazByYATLnaomtg==@mernsms.mongo.cosmos.azure.com:10255/mern-sms?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@mernsms@'
};